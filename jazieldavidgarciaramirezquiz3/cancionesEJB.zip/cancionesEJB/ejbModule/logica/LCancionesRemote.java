package logica;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.ejb.Remote;
import bean.BCancion;
@Remote
public interface LCancionesRemote {
	
	public abstract void ingresar_canciones(BCancion cancion);
	public abstract ArrayList<BCancion> leer();
	public abstract void listar();
	

}
