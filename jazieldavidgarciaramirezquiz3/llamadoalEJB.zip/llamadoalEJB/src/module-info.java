/**
 * 
 */
/**
 * @author Pc
 *
 */
module llamadoalEJB {
	requires java.naming;
}